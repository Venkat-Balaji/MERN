const createUserController = require('@/controllers/middlewaresControllers/createUserController');
module.exports = createUserController('Admin');
