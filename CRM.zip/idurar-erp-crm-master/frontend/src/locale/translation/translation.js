import en_us from './en_us';

const languages = {
  en_us,
};

export default languages;
