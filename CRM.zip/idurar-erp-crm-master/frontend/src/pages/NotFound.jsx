import NotFound from '@/components/NotFound';

const NotFoundPage = () => {
  return <NotFound entity={''} />;
};
export default NotFoundPage;
